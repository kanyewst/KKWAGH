% Dynamic predicate to store flight details
:- dynamic(flight/4).

% define flights

flight(mumbai,delhi,date(2024 ,5 , 10),'AB123').
flight(delhi,goa,date(2024 ,5 , 11),'UK012').
flight(chennai,delhi,date(2024 ,5 , 13),'AD788').

% predicate to initiate flight enquiry

search_flights :-

	write('Welcome to ABC airlines!! how can i assist you?'),nl,
	write('Please Enter your departure city: '),
	read(DepartureCity),
	write('Please Enter your destination city:'),
	read(DestinationCity),
	write('Please Enter Your travel Date:'),nl,
	write('Year: '),
	read(Year),
	write('Month: '),
	read(Month),
	write('Day: '),
	read(Day),
	find_flights(DepartureCity,DestinationCity,date(Year,Month,Day)).

% predicate to find available flights

find_flights(DepartureCity,DestinationCity,TravelDate):-

nl,write('Searching available flights from'),write(DepartureCity),
	write('to'),write(DestinationCity),write('on'),write(TravelDate),nl,
	(	flight(DepartureCity,DestinationCity,TravelDate,FlightNumber)
	->	write('Flight Found!!!'),nl,
		write('Flight Number: '),write(FlightNumber),nl,
		nl,write('Enjoy your flight!!!'),nl
	;	write('No flights found for the searched route and date'),nl
).

% Entry point
:- search_flights.