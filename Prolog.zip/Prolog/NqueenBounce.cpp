#include <iostream>
#include <vector>
#include <queue>
#include <cmath>
using namespace std;

bool isSafe(int row, int col, vector<int>& board) {
    for (int i = 0; i < row; ++i) {
        if (board[i] == col || abs(board[i] - col) == abs(i - row))
            return false;
    }
    return true;
}

struct Node {
    int row;
    vector<int> board;
    Node(int r, const vector<int>& b) : row(r), board(b) {}
};

struct CompareNode {
    bool operator()(const Node& a, const Node& b) const {
        // Custom comparator for priority queue (min-heap based on row number)
        return a.row > b.row;
    }
};

void solveNQueens(int n) {
    vector<int> board(n, -1);
    int count = 0;
    priority_queue<Node, vector<Node>, CompareNode> pq;

    // Initialize priority queue with the first row options
    for (int col = 0; col < n; ++col) {
        if (isSafe(0, col, board)) {
            board[0] = col;
            pq.push(Node(1, board));
            board[0] = -1;  // Reset for next iteration
        }
    }

    while (!pq.empty()) {
        Node current = pq.top();
        pq.pop();

        int row = current.row;
        board = current.board;

        if (row == n) {
            // Found a valid solution
            count++;
            cout << "Solution " << count << ":\n";
            for (int i = 0; i < n; ++i) {
                for (int j = 0; j < n; ++j) {
                    if (board[i] == j)
                        cout << "Q";
                    else
                        cout << ".";
                }
                cout << "\n";
            }
            cout << "\n";
        } else {
            // Explore next row possibilities and add to priority queue
            for (int col = 0; col < n; ++col) {
                if (isSafe(row, col, board)) {
                    board[row] = col;
                    pq.push(Node(row + 1, board));
                    board[row] = -1;  // Reset for next iteration
                }
            }
        }
    }

    cout << "Total Solutions: " << count << "\n";
}

int main() {
    int n;
    cout << "Enter the number of queens (N): ";
    cin >> n;

    solveNQueens(n);

    return 0;
}