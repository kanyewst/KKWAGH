#include<bits/std++.h>
using namespace std;

void bfs_rec(vector<int>vec[],vector<int>&visit,queue<int>&q,vector<int>&ans)
{
	if(q.empty())return;
	int ele = q.front();
	q.pop();
	ans.push_back(ele);
	for(int v:vec[ele])
	{
		if(!visit[v])
		{
			visit[v]=1;
			q.push(v);
		}
	}
	bfs_rec(vec,visit,q,ans);
}
void bfs_search(vector<int>vec[],int n,int target)
{
	vector<int>visit(n+1 , 0);
	queue<int>q;
	vector<int>ans;
	int find = 0;
	for(int i=1; i<=n; i++)
	{
		if(!visit[i])
		{
			visit[i] = 1;
			q.push(i);
			bfs_rec(vec,visit,q,ans);
			if(find) break;
		}
	}
	for(int i =0; i<ans.size() ; i++)
	{
		if(ans[i] == target)
		{
			find = 1;
			break;
		}
	}
	if(find)
	{
		cout<<"Vertex Found!!";
		cout<<"Bfs traversal for vertex"<<target<<"is :";
		for(int v:ans) cout<<v<<" ";
			cout<<"\n";
	}
	else{
		cout<<"Vertex not found";
	}
}
void dfs_rec(vector<int>vec[],vector<int>&visit,stack<int>&st,vector<int>&ans)
{
	if(st.empty())return;
	int n = st.front();
	st.pop();
	ans.push_back(n);
	for(int v:vec[n])
	{
		if(!visit[v])
		{
			visit[v]=1;
			st.push(v);
		}
	}
	dfs_rec(vec,visit,st,ans);
}

void dfs_search(vector<int>vec[], int n, int target)
{
	vector<int>visit(n+1 ,0);
	stack<int>st;
	vector<int>ans;
	int find = 0;

	for(int i =1; i<=n ;i++)
	{
		if(!visit[i])
		{
			visit[i]=1;
			st.push(i);
			dfs_rec(vec,visit,st,ans);
			if(find)break;
		}
	}
	for(int v:ans)
	{
		if(v == target)
		{
			find = 1;
			break;
		}
	}
	if(find)
	{
		cout<<"Vertex found!!!";
		cout<<"Dfs traversal for vertex is : ";
		for(int v:ans) cout<<v<<" ";
	}
	else{
		cout<<"Vertex not found";
	}
}
int main()
{
	int n,edge,v,u;
	cout<<"No. of vertex:";
	cin>>n;
	vector<int>vec[n+1];
	cout<<"Enter No. of Edges:";
	cin>>edge;

	for(int i =0;i<edge;i++)
	{
		cout<<"Enter source index:";
		cin>>u;
		cout<<"Enter destination index:";
		cin>>v;
		vec[u].push_back(v);
		vec[v].push_back(u);
	}
	cout<<"\n GRAPH \n";
	for(int i=1;i<n;i++)
	{
		cout<<i<<"-->";
		for(int v: vec[i]) cout<<v<<" ";
			cout<<"\n"
	}
	int node;
	while(true)
	{
		cout<<"Enter the node to search(press 0 for exit):";
		cin>>node;
		if(node == 0)break;

		cout<<"\n1.BFS\n2.DFS\n3.Exit\n choice:"
		int ch;
		cin>>ch;

		switch(ch)
		{
		case 1:
			bfs_search(vec,n,node);
			break;

		case 2:
			dfs_search(vec,n,node);
			break;

		case 3:
			exit(0);

		default:
			cout<<"Invalid choice";

		}
	}

	return 0;
}
























	
		































































































