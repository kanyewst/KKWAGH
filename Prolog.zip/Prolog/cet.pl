% Dynamic predicate to store college details
:- dynamic(college/2).

% Define colleges
college('College A', cutoff(80, 85)).
college('College B', cutoff(75, 80)).
college('College C', cutoff(70, 75)).
college('College D', cutoff(60, 70)).

% Predicate to initiate college search
search_colleges :-
    write('Welcome to our college search! How can I assist you today?'), nl,
    write('Please enter your preferred course: '),
    read(Course),
    find_colleges(Course).

% Predicate to find available colleges
find_colleges(Course) :-
    nl, write('Searching available colleges for '), write(Course), nl,
    (   college(CollegeName, cutoff(MinCET, MinHSC)),
        MinCET >= CourseCET, MinHSC >= CourseHSC
    ->  write('College Found: '), write(CollegeName), nl,
        write('Cutoff Marks: '), write(MinCET), write(' CET, '), write(MinHSC), write(' HSC'), nl,
        nl, write('Explore more about this college!'), nl
    ;   write('No colleges found matching your preferences.'), nl
    ).

% Entry point
:- search_colleges.
