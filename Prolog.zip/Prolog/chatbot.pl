% Dynamic predicates to store flight information
:- dynamic(flight/4).

% Define flights
flight(chicago, new_york, date(2024, 5, 10), 'AA123').
flight(chicago, los_angeles, date(2024, 5, 11), 'UA456').
flight(new_york, chicago, date(2024, 5, 12), 'AA789').
flight(new_york, los_angeles, date(2024, 5, 13), 'DL789').
flight(los_angeles, chicago, date(2024, 5, 14), 'UA234').
flight(los_angeles, new_york, date(2024, 5, 15), 'DL567').

% Predicate to initiate flight inquiry
search_flights :-
    write('Welcome to our airline! How can I assist you today?'), nl,
    write('Please enter your departure city: '),
    read(DepartureCity),
    write('Please enter your destination city: '),
    read(DestinationCity),
    write('Please enter your travel date:'), nl,
    write('Year: '),
    read(Year),
    write('Month: '),
    read(Month),
    write('Day: '),
    read(Day),
    find_flights(DepartureCity, DestinationCity, date(Year, Month, Day)).

% Predicate to find available flights
find_flights(DepartureCity, DestinationCity, TravelDate) :-
            
            nl, write('Searching for available flights from '), write(DepartureCity),
    write(' to '), write(DestinationCity), write(' on '), write(TravelDate), nl,
    (   flight(DepartureCity, DestinationCity, TravelDate, FlightNumber)
    ->  write('Flight found!'), nl,
        write('Flight Number: '), write(FlightNumber), nl,
        nl, write('Enjoy your flight!'), nl
    ;   write('No flights found for the specified route and date.'), nl
    ).

% Entry point
:- search_flights.
