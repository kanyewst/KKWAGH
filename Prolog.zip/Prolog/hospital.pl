% Dynamic predicates for hospital data
:- dynamic(patient/3).
:- dynamic(appointment/4).

% Define patient and appointment data
patient(john_smith, 'Heart Disease', 'Chicago').
patient(sarah_doe, 'Diabetes', 'New York').

appointment(john_smith, date(2024, 5, 10), 'Dr. Johnson', 'Chicago').
appointment(sarah_doe, date(2024, 5, 12), 'Dr. Lee', 'New York').

% Predicate to initiate appointment inquiry
search_appointments :-
    write('Welcome to our hospital! How can I assist you today?'), nl,
    write('Please enter patient name: '),
    read(PatientName),
    appointment(PatientName, Date, Doctor, Location),
    write('Appointment found!'), nl,
    write('Patient: '), write(PatientName), nl,
    write('Date: '), write(Date), nl,
    write('Doctor: '), write(Doctor), nl,
    write('Location: '), write(Location), nl,
    nl, write('Have a good day!'), nl.

% Entry point
:- search_appointments.