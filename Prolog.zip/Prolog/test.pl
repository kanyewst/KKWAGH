:- initialization(main).

main :-
    read_line_to_string(user_input, Input),
    process_input(Input).

process_input(Input) :-
    ( Input = "hello" ->
        respond('Hello! How are you today?')
    ; Input = "hi" ->
        respond('Hi there! How are you feeling?')
    ; Input = "hey" ->
        respond('Hey! How are you doing?')
    ; Input = "good" ->
        respond('I\'m glad to hear that you\'re feeling good!')
    ; Input = "good morning" ->
        respond('Good Morning!! Have a nice day')
    ; Input = "bad" ->
        respond('I\'m sorry to hear that. Is there anything I can do to help?')
    ; otherwise ->
        respond('I\'m sorry, I didn\'t understand that. Could you please repeat?')
    ).

respond(Message) :-
    write(Message), nl.
